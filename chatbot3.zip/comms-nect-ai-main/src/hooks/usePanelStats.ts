import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function usePanelStats() {
  const statsQuery = useQuery({
    queryKey: ["panel-stats"],
    queryFn: async () => {
      const [agentsRes, inProgressRes, inQueueRes, todayRes] = await Promise.all([
        supabase
          .from("profiles")
          .select("*", { count: "exact", head: true })
          .eq("is_online", true)
          .abortSignal(AbortSignal.timeout(15000)),
        supabase
          .from("conversations")
          .select("*", { count: "exact", head: true })
          .eq("status", "in_progress")
          .abortSignal(AbortSignal.timeout(15000)),
        supabase
          .from("conversations")
          .select("*", { count: "exact", head: true })
          .eq("status", "new")
          .abortSignal(AbortSignal.timeout(15000)),
        supabase
          .from("conversations")
          .select("created_at, updated_at")
          .eq("status", "in_progress")
          .abortSignal(AbortSignal.timeout(15000)),
      ]);

      // Calculate average time for active conversations
      let totalTime = 0;
      let count = 0;
      const now = new Date();
      todayRes.data?.forEach((c) => {
        const start = new Date(c.created_at);
        const duration = now.getTime() - start.getTime();
        if (duration > 0) {
          totalTime += duration;
          count++;
        }
      });
      const avgTimeMinutes = count > 0 ? Math.round(totalTime / count / 60000) : 0;

      return {
        agentsOnline: agentsRes.count || 0,
        inProgress: inProgressRes.count || 0,
        inQueue: inQueueRes.count || 0,
        avgTimeMinutes,
      };
    },
    refetchInterval: 10000,
  });

  return {
    stats: statsQuery.data,
    isLoading: statsQuery.isLoading,
    isError: statsQuery.isError,
    error: statsQuery.error,
    refetch: statsQuery.refetch,
  };
}

export function useActivityLog() {
  const activitiesQuery = useQuery({
    queryKey: ["activity-log"],
    queryFn: async () => {
      const { data } = await supabase
        .from("activity_logs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20)
        .abortSignal(AbortSignal.timeout(15000));

      if (!data || data.length === 0) return [];

      // Fetch user names for activity logs
      const userIds = [...new Set(data.map(log => log.user_id).filter(Boolean))] as string[];
      let profilesMap: Record<string, string> = {};

      if (userIds.length > 0) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, name")
          .in("user_id", userIds)
          .abortSignal(AbortSignal.timeout(15000));

        if (profiles) {
          profilesMap = profiles.reduce((acc, p) => {
            acc[p.user_id] = p.name;
            return acc;
          }, {} as Record<string, string>);
        }
      }

      return data.map(log => ({
        ...log,
        userName: log.user_id ? profilesMap[log.user_id] || null : null,
      }));
    },
    refetchInterval: 15000,
  });

  return {
    activities: activitiesQuery.data || [],
    isLoading: activitiesQuery.isLoading,
    isError: activitiesQuery.isError,
    error: activitiesQuery.error,
    refetch: activitiesQuery.refetch,
  };
}

export function useRecentConversationsPanel() {
  const conversationsQuery = useQuery({
    queryKey: ["panel-recent-conversations"],
    queryFn: async () => {
      const { data } = await supabase
        .from("conversations")
        .select(`
          id,
          status,
          created_at,
          updated_at,
          assigned_to,
          contact_id,
          contacts (name, phone)
        `)
        .order("updated_at", { ascending: false })
        .limit(10)
        .abortSignal(AbortSignal.timeout(15000));

      if (!data) return [];

      // Fetch profile names separately for assigned_to
      const assignedIds = [...new Set(data.filter(c => c.assigned_to).map(c => c.assigned_to))];
      let profilesMap: Record<string, string> = {};

      if (assignedIds.length > 0) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, name")
          .in("user_id", assignedIds)
          .abortSignal(AbortSignal.timeout(15000));
        
        if (profiles) {
          profilesMap = profiles.reduce((acc, p) => {
            acc[p.user_id] = p.name;
            return acc;
          }, {} as Record<string, string>);
        }
      }

      return data.map(conv => ({
        ...conv,
        assignedName: conv.assigned_to ? profilesMap[conv.assigned_to] : null,
      }));
    },
    refetchInterval: 10000,
  });

  return {
    conversations: conversationsQuery.data || [],
    isLoading: conversationsQuery.isLoading,
    isError: conversationsQuery.isError,
    error: conversationsQuery.error,
    refetch: conversationsQuery.refetch,
  };
}
