import { useEffect, useState, useRef } from "react";
import { Plus, Trash2, Save, Upload, Loader2, X, CheckCircle2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useQueues } from "@/hooks/useQueues";
import { useUsers } from "@/hooks/useUsers";
import { useWhatsAppConnections } from "@/hooks/useWhatsAppConnections";
import { useKanbanColumns } from "@/hooks/useKanbanColumns";
import { useTags } from "@/hooks/useTags";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { Node } from "@xyflow/react";

interface NodeConfigPanelProps {
  node: Node | null;
  open: boolean;
  onClose: () => void;
  onUpdate: (nodeId: string, data: Record<string, unknown>) => void;
  onDelete?: (nodeId: string) => void;
  onSaveFlow?: () => void;
  isSaving?: boolean;
}

const LOVABLE_AI_MODELS = [
  { value: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (Recomendado)" },
  { value: "google/gemini-2.5-flash-lite", label: "Gemini 2.5 Flash Lite" },
  { value: "google/gemini-2.5-pro", label: "Gemini 2.5 Pro" },
  { value: "openai/gpt-5", label: "GPT-5" },
  { value: "openai/gpt-5-mini", label: "GPT-5 Mini" },
  { value: "openai/gpt-5-nano", label: "GPT-5 Nano" },
];

const GOOGLE_AI_MODELS = [
  { value: "gemini-2.0-flash", label: "Gemini 2.0 Flash (Mais Recente)" },
  { value: "gemini-1.5-flash", label: "Gemini 1.5 Flash" },
  { value: "gemini-1.5-pro", label: "Gemini 1.5 Pro" },
];

export function NodeConfigPanel({ node, open, onClose, onUpdate, onDelete, onSaveFlow, isSaving }: NodeConfigPanelProps) {
  const [formData, setFormData] = useState<Record<string, unknown>>({});
  const [isUploading, setIsUploading] = useState(false);
  const [isValidatingApiKey, setIsValidatingApiKey] = useState(false);
  const [apiKeyValidation, setApiKeyValidation] = useState<'idle' | 'valid' | 'invalid'>('idle');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { data: queues } = useQueues();
  const { data: users } = useUsers();
  const { connections } = useWhatsAppConnections();
  const { data: kanbanColumns } = useKanbanColumns();
  const { data: tags } = useTags();

  // Função para validar API key do Google AI
  const validateGoogleApiKey = async (apiKey: string) => {
    if (!apiKey || apiKey.length < 10) {
      setApiKeyValidation('invalid');
      toast.error("API key inválida");
      return false;
    }

    setIsValidatingApiKey(true);
    setApiKeyValidation('idle');

    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ role: "user", parts: [{ text: "Olá" }] }],
            generationConfig: { maxOutputTokens: 10 },
          }),
        }
      );

      if (response.ok) {
        setApiKeyValidation('valid');
        toast.success("API key válida!");
        return true;
      } else {
        const errorData = await response.json().catch(() => ({}));
        console.error("API key validation error:", errorData);
        setApiKeyValidation('invalid');
        toast.error("API key inválida ou sem permissão");
        return false;
      }
    } catch (error) {
      console.error("Error validating API key:", error);
      setApiKeyValidation('invalid');
      toast.error("Erro ao validar API key");
      return false;
    } finally {
      setIsValidatingApiKey(false);
    }
  };

  // Reset validation when API key changes
  useEffect(() => {
    if (formData.googleApiKey) {
      setApiKeyValidation('idle');
    }
  }, [formData.googleApiKey]);

  useEffect(() => {
    if (node) {
      setFormData(node.data as Record<string, unknown>);
    }
  }, [node]);

  if (!node) return null;

  const handleChange = (key: string, value: unknown) => {
    const newData = { ...formData, [key]: value };
    setFormData(newData);
    onUpdate(node.id, newData);
  };

  const handleAddOption = () => {
    const options = (formData.options as Array<{ id: string; text: string }>) || [];
    const newOption = { id: `opt_${Date.now()}`, text: "" };
    handleChange("options", [...options, newOption]);
  };

  const handleRemoveOption = (optionId: string) => {
    const options = (formData.options as Array<{ id: string; text: string }>) || [];
    handleChange("options", options.filter((o) => o.id !== optionId));
  };

  const handleOptionChange = (optionId: string, text: string) => {
    const options = (formData.options as Array<{ id: string; text: string }>) || [];
    handleChange(
      "options",
      options.map((o) => (o.id === optionId ? { ...o, text } : o))
    );
  };

  const renderFields = () => {
    switch (node.type) {
      case "trigger":
        return (
          <>
            <div className="space-y-2">
              <Label>Nome do bloco</Label>
              <Input
                value={(formData.label as string) || ""}
                onChange={(e) => handleChange("label", e.target.value)}
                placeholder="Gatilho"
              />
            </div>
            <div className="space-y-2">
              <Label>Tipo de gatilho</Label>
              <Select
                value={(formData.triggerType as string) || "keyword"}
                onValueChange={(v) => handleChange("triggerType", v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="keyword">Palavra-chave</SelectItem>
                  <SelectItem value="phrase">Frase</SelectItem>
                  <SelectItem value="new_conversation">Nova conversa</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {formData.triggerType === "keyword" && (
              <div className="space-y-2">
                <Label>Palavra-chave</Label>
                <Input
                  value={(formData.triggerValue as string) || ""}
                  onChange={(e) => handleChange("triggerValue", e.target.value)}
                  placeholder="Ex: oi, olá, menu"
                />
              </div>
            )}
            {formData.triggerType === "phrase" && (
              <div className="space-y-2">
                <Label>Frase</Label>
                <Input
                  value={(formData.triggerValue as string) || ""}
                  onChange={(e) => handleChange("triggerValue", e.target.value)}
                  placeholder="Ex: quero fazer um pedido"
                />
                <p className="text-xs text-muted-foreground">
                  A frase será comparada parcialmente com a mensagem do usuário
                </p>
              </div>
            )}
          </>
        );

      case "message":
        const messageType = (formData.messageType as string) || "text";
        return (
          <>
            <div className="space-y-2">
              <Label>Nome do bloco</Label>
              <Input
                value={(formData.label as string) || ""}
                onChange={(e) => handleChange("label", e.target.value)}
                placeholder="Mensagem"
              />
            </div>
            <div className="space-y-2">
              <Label>Tipo de mensagem</Label>
              <Select
                value={messageType}
                onValueChange={(v) => handleChange("messageType", v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text">Texto</SelectItem>
                  <SelectItem value="image">Imagem</SelectItem>
                  <SelectItem value="video">Vídeo</SelectItem>
                  <SelectItem value="document">Documento</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {messageType === "text" && (
              <div className="space-y-2">
                <Label>Conteúdo da mensagem</Label>
                <Textarea
                  value={(formData.content as string) || ""}
                  onChange={(e) => handleChange("content", e.target.value)}
                  placeholder="Digite a mensagem que será enviada..."
                  rows={4}
                />
                <p className="text-xs text-muted-foreground">
                  Use {"{{nome}}"} para inserir variáveis
                </p>
              </div>
            )}
            {(messageType === "image" || messageType === "video" || messageType === "document") && (
              <>
                <div className="space-y-2">
                  <Label>Arquivo de mídia</Label>
                  <div className="flex gap-2">
                    <Input
                      value={(formData.mediaUrl as string) || ""}
                      onChange={(e) => handleChange("mediaUrl", e.target.value)}
                      placeholder={`https://exemplo.com/${messageType === "image" ? "imagem.jpg" : messageType === "video" ? "video.mp4" : "documento.pdf"}`}
                      className="flex-1"
                    />
                    {formData.mediaUrl && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleChange("mediaUrl", "")}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept={
                      messageType === "image" 
                        ? "image/*" 
                        : messageType === "video" 
                        ? "video/*" 
                        : "*/*"
                    }
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      
                      setIsUploading(true);
                      try {
                        const fileExt = file.name.split('.').pop();
                        const fileName = `${crypto.randomUUID()}.${fileExt}`;
                        const filePath = `chatbot/${fileName}`;
                        
                        const { error: uploadError } = await supabase.storage
                          .from('whatsapp-media')
                          .upload(filePath, file);
                          
                        if (uploadError) throw uploadError;
                        
                        const { data: { publicUrl } } = supabase.storage
                          .from('whatsapp-media')
                          .getPublicUrl(filePath);
                          
                        handleChange("mediaUrl", publicUrl);
                        toast.success("Arquivo enviado com sucesso!");
                      } catch (error) {
                        console.error("Upload error:", error);
                        toast.error("Erro ao enviar arquivo");
                      } finally {
                        setIsUploading(false);
                        if (fileInputRef.current) {
                          fileInputRef.current.value = "";
                        }
                      }
                    }}
                  />
                  <Button
                    variant="outline"
                    className="w-full gap-2"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                  >
                    {isUploading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4" />
                        Fazer upload
                      </>
                    )}
                  </Button>
                  <p className="text-xs text-muted-foreground">
                    Envie um arquivo ou cole a URL direta
                  </p>
                  {messageType === "image" && formData.mediaUrl && (
                    <div className="mt-2 rounded-lg overflow-hidden border border-border">
                      <img 
                        src={formData.mediaUrl as string} 
                        alt="Preview" 
                        className="w-full h-32 object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none';
                        }}
                      />
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <Label>Legenda (opcional)</Label>
                  <Textarea
                    value={(formData.caption as string) || ""}
                    onChange={(e) => handleChange("caption", e.target.value)}
                    placeholder="Digite uma legenda para a mídia..."
                    rows={2}
                  />
                </div>
              </>
            )}
          </>
        );



      case "delay":
        return (
          <>
            <div className="space-y-2">
              <Label>Nome do bloco</Label>
              <Input
                value={(formData.label as string) || ""}
                onChange={(e) => handleChange("label", e.target.value)}
                placeholder="Aguardar"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-2">
                <Label>Tempo</Label>
                <Input
                  type="number"
                  min={1}
                  value={(formData.delay as number) || ""}
                  onChange={(e) => handleChange("delay", parseInt(e.target.value))}
                  placeholder="5"
                />
              </div>
              <div className="space-y-2">
                <Label>Unidade</Label>
                <Select
                  value={(formData.unit as string) || "seconds"}
                  onValueChange={(v) => handleChange("unit", v)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="seconds">Segundos</SelectItem>
                    <SelectItem value="minutes">Minutos</SelectItem>
                    <SelectItem value="hours">Horas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </>
        );

      case "menu":
        const options = (formData.options as Array<{ id: string; text: string }>) || [];
        return (
          <>
            <div className="space-y-2">
              <Label>Nome do bloco</Label>
              <Input
                value={(formData.label as string) || ""}
                onChange={(e) => handleChange("label", e.target.value)}
                placeholder="Menu"
              />
            </div>
            <div className="space-y-2">
              <Label>Título do menu</Label>
              <Input
                value={(formData.title as string) || ""}
                onChange={(e) => handleChange("title", e.target.value)}
                placeholder="Escolha uma opção:"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Opções</Label>
                <Button variant="ghost" size="sm" onClick={handleAddOption}>
                  <Plus className="w-4 h-4 mr-1" />
                  Adicionar
                </Button>
              </div>
              <div className="space-y-2">
                {options.map((option, index) => (
                  <div key={option.id} className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground w-6">{index + 1}.</span>
                    <Input
                      value={option.text}
                      onChange={(e) => handleOptionChange(option.id, e.target.value)}
                      placeholder={`Opção ${index + 1}`}
                      className="flex-1"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleRemoveOption(option.id)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </>
        );

      case "ai":
        const useOwnApiKey = (formData.useOwnApiKey as boolean) ?? false;
        const aiModels = useOwnApiKey ? GOOGLE_AI_MODELS : LOVABLE_AI_MODELS;
        const defaultModel = useOwnApiKey ? "gemini-2.0-flash" : "google/gemini-2.5-flash";
        
        return (
          <>
            <div className="space-y-2">
              <Label>Nome do bloco</Label>
              <Input
                value={(formData.label as string) || ""}
                onChange={(e) => handleChange("label", e.target.value)}
                placeholder="IA"
              />
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <div className="space-y-0.5">
                <Label>Ativar IA</Label>
                <p className="text-xs text-muted-foreground">Responder automaticamente</p>
              </div>
              <Switch
                checked={(formData.isEnabled as boolean) ?? true}
                onCheckedChange={(v) => handleChange("isEnabled", v)}
              />
            </div>
            
            {/* Toggle para API própria */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border border-primary/20">
              <div className="space-y-0.5">
                <Label className="flex items-center gap-2">
                  Usar API key própria
                  <span className="text-[10px] bg-green-500/20 text-green-600 dark:text-green-400 px-1.5 py-0.5 rounded font-medium">
                    GRATUITO
                  </span>
                </Label>
                <p className="text-xs text-muted-foreground">
                  Use sua chave do{" "}
                  <a 
                    href="https://aistudio.google.com/apikey" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-primary underline hover:no-underline"
                  >
                    Google AI Studio
                  </a>
                </p>
              </div>
              <Switch
                checked={useOwnApiKey}
                onCheckedChange={(v) => {
                  const newModel = v ? "gemini-2.0-flash" : "google/gemini-2.5-flash";
                  const newData = { 
                    ...formData, 
                    useOwnApiKey: v, 
                    model: newModel 
                  };
                  setFormData(newData);
                  onUpdate(node.id, newData);
                }}
              />
            </div>
            
            {/* Campo de API Key - aparece quando useOwnApiKey é true */}
            {useOwnApiKey && (
              <div className="space-y-3 p-3 rounded-lg border border-dashed border-primary/30 bg-primary/5">
                <Label>Google AI API Key</Label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Input
                      type="password"
                      value={(formData.googleApiKey as string) || ""}
                      onChange={(e) => handleChange("googleApiKey", e.target.value)}
                      placeholder="AIza..."
                      className={
                        apiKeyValidation === 'valid' 
                          ? "pr-8 border-green-500 focus-visible:ring-green-500" 
                          : apiKeyValidation === 'invalid' 
                          ? "pr-8 border-destructive focus-visible:ring-destructive" 
                          : ""
                      }
                    />
                    {apiKeyValidation === 'valid' && (
                      <CheckCircle2 className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-green-500" />
                    )}
                    {apiKeyValidation === 'invalid' && (
                      <AlertCircle className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-destructive" />
                    )}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => validateGoogleApiKey((formData.googleApiKey as string) || "")}
                    disabled={isValidatingApiKey || !(formData.googleApiKey as string)}
                    className="shrink-0"
                  >
                    {isValidatingApiKey ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                        Testando...
                      </>
                    ) : (
                      "Testar"
                    )}
                  </Button>
                </div>
                {apiKeyValidation === 'valid' && (
                  <p className="text-xs text-green-600 dark:text-green-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    API key verificada e funcionando
                  </p>
                )}
                {apiKeyValidation === 'invalid' && (
                  <p className="text-xs text-destructive flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    API key inválida. Verifique e tente novamente.
                  </p>
                )}
                <p className="text-xs text-muted-foreground">
                  Obtenha gratuitamente em{" "}
                  <a 
                    href="https://aistudio.google.com/apikey" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-primary underline hover:no-underline"
                  >
                    aistudio.google.com/apikey
                  </a>
                </p>
              </div>
            )}
            
            <div className="space-y-2">
              <Label>Modelo de IA</Label>
              <Select
                value={aiModels.some(m => m.value === formData.model) ? (formData.model as string) : defaultModel}
                onValueChange={(v) => handleChange("model", v)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um modelo" />
                </SelectTrigger>
                <SelectContent>
                  {aiModels.map((model) => (
                    <SelectItem key={model.value} value={model.value}>
                      {model.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>System Prompt</Label>
              <Textarea
                value={(formData.systemPrompt as string) || ""}
                onChange={(e) => handleChange("systemPrompt", e.target.value)}
                placeholder="Você é um assistente amigável que ajuda os clientes..."
                rows={4}
              />
              <p className="text-xs text-muted-foreground">
                Instruções para o comportamento da IA
              </p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Temperatura: {(formData.temperature as number) ?? 0.7}</Label>
              </div>
              <Slider
                value={[(formData.temperature as number) ?? 0.7]}
                onValueChange={(v) => handleChange("temperature", v[0])}
                min={0}
                max={2}
                step={0.1}
              />
              <p className="text-xs text-muted-foreground">
                Menor = mais preciso, Maior = mais criativo
              </p>
            </div>
            <div className="space-y-2">
              <Label>Max Tokens</Label>
              <Input
                type="number"
                min={100}
                max={4096}
                value={(formData.maxTokens as number) || 1024}
                onChange={(e) => handleChange("maxTokens", parseInt(e.target.value))}
                placeholder="1024"
              />
            </div>
            <div className="space-y-2">
              <Label>Base de conhecimento (opcional)</Label>
              <Textarea
                value={(formData.knowledgeBase as string) || ""}
                onChange={(e) => handleChange("knowledgeBase", e.target.value)}
                placeholder="Informações sobre produtos, preços, políticas..."
                rows={4}
              />
              <p className="text-xs text-muted-foreground">
                Contexto adicional para a IA consultar
              </p>
            </div>
          </>
        );

      case "crm":
        return (
          <>
            <div className="space-y-2">
              <Label>Nome do bloco</Label>
              <Input
                value={(formData.label as string) || ""}
                onChange={(e) => handleChange("label", e.target.value)}
                placeholder="CRM"
              />
            </div>
            <div className="space-y-2">
              <Label>Etapa do Kanban</Label>
              <Select
                value={(formData.kanbanColumnId as string) || ""}
                onValueChange={(v) => {
                  const column = kanbanColumns?.find((c) => c.id === v);
                  handleChange("kanbanColumnId", v);
                  handleChange("kanbanColumnName", column?.name || "");
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a etapa..." />
                </SelectTrigger>
                <SelectContent>
                  {kanbanColumns?.map((column) => (
                    <SelectItem key={column.id} value={column.id}>
                      <div className="flex items-center gap-2">
                        {column.color && (
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: column.color }}
                          />
                        )}
                        {column.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                O contato será movido para esta etapa do CRM
              </p>
            </div>
          </>
        );

      case "whatsapp":
        return (
          <>
            <div className="space-y-2">
              <Label>Nome do bloco</Label>
              <Input
                value={(formData.label as string) || ""}
                onChange={(e) => handleChange("label", e.target.value)}
                placeholder="WhatsApp"
              />
            </div>
            <div className="space-y-2">
              <Label>Número de WhatsApp</Label>
              <Select
                value={(formData.connectionId as string) || ""}
                onValueChange={(v) => {
                  const connection = connections?.find((c) => c.id === v);
                  handleChange("connectionId", v);
                  handleChange("connectionName", connection?.name || "");
                  handleChange("phoneNumber", connection?.phone_number || "");
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o número..." />
                </SelectTrigger>
                <SelectContent position="popper" sideOffset={5}>
                  {connections?.map((conn) => (
                    <SelectItem key={conn.id} value={conn.id}>
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${conn.status === "connected" ? "bg-success" : "bg-muted"}`} />
                        {conn.name} {conn.phone_number && `(${conn.phone_number})`}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Define qual número de WhatsApp será usado nesta parte do fluxo
              </p>
            </div>
          </>
        );

      case "transfer":
        const transferType = (formData.transferType as string) || "queue";
        return (
          <>
            <div className="space-y-2">
              <Label>Nome do bloco</Label>
              <Input
                value={(formData.label as string) || ""}
                onChange={(e) => handleChange("label", e.target.value)}
                placeholder="Transferir"
              />
            </div>
            <div className="space-y-2">
              <Label>Tipo de transferência</Label>
              <Select
                value={transferType}
                onValueChange={(v) => {
                  handleChange("transferType", v);
                  // Reset related fields
                  handleChange("queueId", "");
                  handleChange("queueName", "");
                  handleChange("agentId", "");
                  handleChange("agentName", "");
                  handleChange("connectionId", "");
                  handleChange("connectionName", "");
                }}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent position="popper" sideOffset={5}>
                  <SelectItem value="queue">Setor/Fila</SelectItem>
                  <SelectItem value="agent">Atendente específico</SelectItem>
                  <SelectItem value="whatsapp">Número de WhatsApp</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {transferType === "queue" && (
              <div className="space-y-2">
                <Label>Setor/Fila</Label>
                <Select
                  value={(formData.queueId as string) || ""}
                  onValueChange={(v) => {
                    const queue = queues?.find((q) => q.id === v);
                    handleChange("queueId", v);
                    handleChange("queueName", queue?.name || "");
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o setor..." />
                  </SelectTrigger>
                  <SelectContent position="popper" sideOffset={5}>
                    {queues?.map((queue) => (
                      <SelectItem key={queue.id} value={queue.id}>
                        {queue.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {transferType === "agent" && (
              <div className="space-y-2">
                <Label>Atendente</Label>
                <Select
                  value={(formData.agentId as string) || ""}
                  onValueChange={(v) => {
                    const agent = users?.find((u) => u.id === v);
                    handleChange("agentId", v);
                    handleChange("agentName", agent?.name || "");
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o atendente..." />
                  </SelectTrigger>
                  <SelectContent position="popper" sideOffset={5}>
                    {users?.map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${user.is_online ? "bg-success" : "bg-muted"}`} />
                          {user.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {transferType === "whatsapp" && (
              <div className="space-y-2">
                <Label>Número de WhatsApp</Label>
                <Select
                  value={(formData.connectionId as string) || ""}
                  onValueChange={(v) => {
                    const connection = connections?.find((c) => c.id === v);
                    handleChange("connectionId", v);
                    handleChange("connectionName", connection?.name || connection?.phone_number || "");
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o número..." />
                  </SelectTrigger>
                  <SelectContent position="popper" sideOffset={5}>
                    {connections?.map((conn) => (
                      <SelectItem key={conn.id} value={conn.id}>
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${conn.status === "connected" ? "bg-success" : "bg-muted"}`} />
                          {conn.name} {conn.phone_number && `(${conn.phone_number})`}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-2">
              <Label>Mensagem de transferência</Label>
              <Textarea
                value={(formData.message as string) || ""}
                onChange={(e) => handleChange("message", e.target.value)}
                placeholder="Você está sendo transferido para..."
                rows={2}
              />
            </div>
          </>
        );

      case "end":
        return (
          <>
            <div className="space-y-2">
              <Label>Nome do bloco</Label>
              <Input
                value={(formData.label as string) || ""}
                onChange={(e) => handleChange("label", e.target.value)}
                placeholder="Encerrar"
              />
            </div>
            <div className="space-y-2">
              <Label>Mensagem de encerramento (opcional)</Label>
              <Textarea
                value={(formData.message as string) || ""}
                onChange={(e) => handleChange("message", e.target.value)}
                placeholder="Obrigado pelo contato!"
                rows={2}
              />
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <div className="space-y-0.5">
                <Label>Marcar como resolvido</Label>
                <p className="text-xs text-muted-foreground">Encerrar e resolver a conversa</p>
              </div>
              <Switch
                checked={(formData.markAsResolved as boolean) ?? true}
                onCheckedChange={(v) => handleChange("markAsResolved", v)}
              />
            </div>
          </>
        );

      case "schedule":
        return (
          <>
            <div className="space-y-2">
              <Label>Nome do bloco</Label>
              <Input
                value={(formData.label as string) || ""}
                onChange={(e) => handleChange("label", e.target.value)}
                placeholder="Agendar"
              />
            </div>
            <div className="space-y-2">
              <Label>Tipo de ação</Label>
              <Select
                value={(formData.actionType as string) || "check_availability"}
                onValueChange={(v) => handleChange("actionType", v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="check_availability">Verificar disponibilidade</SelectItem>
                  <SelectItem value="create_event">Criar agendamento</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {(formData.actionType === "check_availability" || !formData.actionType) && (
              <>
                <div className="space-y-2">
                  <Label>Período para buscar</Label>
                  <Select
                    value={(formData.period as string) || "today"}
                    onValueChange={(v) => handleChange("period", v)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="today">Hoje</SelectItem>
                      <SelectItem value="tomorrow">Amanhã</SelectItem>
                      <SelectItem value="next_3_days">Próximos 3 dias</SelectItem>
                      <SelectItem value="next_7_days">Próximos 7 dias</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Duração do serviço (minutos)</Label>
                  <Select
                    value={String((formData.serviceDuration as number) || 60)}
                    onValueChange={(v) => handleChange("serviceDuration", parseInt(v))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 minutos</SelectItem>
                      <SelectItem value="30">30 minutos</SelectItem>
                      <SelectItem value="45">45 minutos</SelectItem>
                      <SelectItem value="60">1 hora</SelectItem>
                      <SelectItem value="90">1h30</SelectItem>
                      <SelectItem value="120">2 horas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-2">
                    <Label>Horário início</Label>
                    <Input
                      type="time"
                      value={(formData.workingHoursStart as string) || "09:00"}
                      onChange={(e) => handleChange("workingHoursStart", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Horário fim</Label>
                    <Input
                      type="time"
                      value={(formData.workingHoursEnd as string) || "18:00"}
                      onChange={(e) => handleChange("workingHoursEnd", e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Máximo de opções a mostrar</Label>
                  <Select
                    value={String((formData.maxOptions as number) || 5)}
                    onValueChange={(v) => handleChange("maxOptions", parseInt(v))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3 horários</SelectItem>
                      <SelectItem value="5">5 horários</SelectItem>
                      <SelectItem value="10">10 horários</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            {formData.actionType === "create_event" && (
              <>
                <div className="space-y-2">
                  <Label>Título do evento</Label>
                  <Input
                    value={(formData.eventTitle as string) || ""}
                    onChange={(e) => handleChange("eventTitle", e.target.value)}
                    placeholder="Consulta com {{nome}}"
                  />
                  <p className="text-xs text-muted-foreground">
                    Use {"{{nome}}"} para inserir variáveis
                  </p>
                </div>
                <div className="space-y-2">
                  <Label>Descrição do evento (opcional)</Label>
                  <Textarea
                    value={(formData.eventDescription as string) || ""}
                    onChange={(e) => handleChange("eventDescription", e.target.value)}
                    placeholder="Agendamento realizado via WhatsApp"
                    rows={2}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Duração do evento (minutos)</Label>
                  <Select
                    value={String((formData.eventDuration as number) || 60)}
                    onValueChange={(v) => handleChange("eventDuration", parseInt(v))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 minutos</SelectItem>
                      <SelectItem value="30">30 minutos</SelectItem>
                      <SelectItem value="45">45 minutos</SelectItem>
                      <SelectItem value="60">1 hora</SelectItem>
                      <SelectItem value="90">1h30</SelectItem>
                      <SelectItem value="120">2 horas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="space-y-0.5">
                    <Label>Enviar confirmação</Label>
                    <p className="text-xs text-muted-foreground">Enviar mensagem de confirmação ao cliente</p>
                  </div>
                  <Switch
                    checked={(formData.sendConfirmation as boolean) ?? true}
                    onCheckedChange={(v) => handleChange("sendConfirmation", v)}
                  />
                </div>
              </>
            )}

            <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
              <p className="text-xs text-blue-600 dark:text-blue-400">
                <strong>Dica:</strong> Configure a integração com Google Agenda em Integrações para usar este bloco.
              </p>
            </div>
          </>
        );

      default:
        return null;
    }
  };

  const getTitle = () => {
    const titles: Record<string, string> = {
      trigger: "Configurar Gatilho",
      message: "Configurar Mensagem",
      whatsapp: "Configurar WhatsApp",
      delay: "Configurar Aguardar",
      menu: "Configurar Menu",
      ai: "Configurar IA",
      condition: "Configurar Condição",
      crm: "Configurar CRM",
      transfer: "Configurar Transferência",
      end: "Configurar Encerramento",
      schedule: "Configurar Agendamento",
    };
    return titles[node.type || ""] || "Configurar Bloco";
  };

  const handleDelete = () => {
    if (node && onDelete) {
      onDelete(node.id);
      onClose();
    }
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="max-w-md h-[85vh] flex flex-col">
        <DialogHeader className="flex-shrink-0 pb-4">
          <DialogTitle>{getTitle()}</DialogTitle>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto min-h-0 pr-2">
          <div className="space-y-4 pb-4">{renderFields()}</div>
        </div>
        <div className="pt-4 border-t border-border space-y-2 flex-shrink-0">
          {onSaveFlow && (
            <Button
              className="w-full gap-2"
              onClick={onSaveFlow}
              disabled={isSaving}
            >
              <Save className="w-4 h-4" />
              {isSaving ? "Salvando..." : "Salvar fluxo"}
            </Button>
          )}
          {onDelete && (
            <Button
              variant="destructive"
              className="w-full gap-2"
              onClick={handleDelete}
            >
              <Trash2 className="w-4 h-4" />
              Excluir bloco
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
